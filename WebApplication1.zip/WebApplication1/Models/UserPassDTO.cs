﻿namespace WebApplication1.Models
{
    public class UserPassDTO : User
    {
        public string? Password { get; set; }
    }
}




















